package pack1;

public class pubAccessSpecifiers {
	public void display() { 
		System.out.println("This is Public Access Specifiers"); 
    } 
}
