package projectseven;


public class innerClass1 {
	private String msg="Inner Classes";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
		 }  
	     Inner l=new Inner();  
		 l.msg();  
	 }  

	 
	public static void main(String[] args) {
		innerClass1  ob=new innerClass1();  
		ob.display();  
	}
}
